#pragma once

#include "BufferManager.h"
#include "DSManager.h"
#include<fstream>
#include<iostream>
using namespace std;


DSManager::DSManager()
{
	file = NULL;
	int i = 0;
	for(i = 0; i < MAXPAGES; i++)
	{
		pages[i] = -1;
	}
}


/************************************************************************************
*OpenFile function is called anytime a file needs to be opened for reading or writing.
*The prototype for this function is OpenFile(String filename) and returns an error code.
*The function opens the file specified by the filename.
*************************************************************************************/
int DSManager::OpenFile(string filename)
{
	//file.open(filename,ios_base::in|ios_base::out|ios_base::app);
	//return 1;
	file = fopen(filename.c_str(),"r+");
	if(file == NULL)
	{
		return 1;
	}
	//fseek(file, 0, SEEK_END);
	//numPages = (ftell(file) / FRAMESIZE);
	//fseek(file, 0, SEEK_SET);
	return 0;
}

/************************************************************************************
*CloseFile function is called when the data file needs to be closed.  The protoype is
*CloseFile() and returns an error code.  This function closes the file that is in current
*use.  This function should only be called as the database is changed or a the program closes.
*************************************************************************************/
int DSManager::CloseFile()
{
	//file.close();
	fclose(file); 
	file = NULL; 

	return 0;
}

/************************************************************************************
*ReadPage function is called by the FixPage function in the buffer manager.  This 
*prototype is ReadPage(page_id, bytes) and returns what it has read in.  This function
*calls fseek() and  fread() to gain data from a file.
*************************************************************************************/
bFrame DSManager::ReadPage(int page_id)
{
	int iread = 0;
	bFrame bf_ds;
	//C
	//SEEK_CUR��Current position of file pointer.
	//SEEK_END:End of file.
	//SEEK_SET:Beginning of file.
	fseek(file,page_id*FRAMESIZE,SEEK_SET);
	iread = (int)fread(&bf_ds,sizeof(bf_ds),1,file);
	
	return bf_ds;
}


/************************************************************************************
*WritePage function is called whenever a page is taken out of the buffer.  
*The prototype is WritePage(frame_id, frm) and returns how many bytes were written.  
*This function calls fseek() and fwrite() to save data into a file.
*************************************************************************************/
int DSManager::WritePage(int page_id, bFrame frm)
{
	int bytesw = 0;
	fseek(file,page_id*FRAMESIZE,SEEK_SET);

	bytesw = (int)fwrite(&frm,sizeof(frm),1,file);
	return bytesw;

	//int page_id = bm->Hash(frame_id);
	//int size= DEFBUFSIZE*FRAMESIZE;
	//file.seekg(page_id,ios_base::cur);//��page_id����ʼд
	//file.write(cbuf,size);

}

//�ļ�ָ�����//
int DSManager::Seek(int offset, int pos)
{
	//C++
	//ios_base::beg �����ļ���ʼλ��
	//ios_base::cur �����ļ���ǰλ��
	//ios_base::end �����ļ�ĩβλ��
	//C
	fseek(file,offset,pos);
	//file.seekg(pos,ios_base::beg);
	return 1;
}


void DSManager::IncNumPages()
{
	numPages++;
}

//returns the page counter.
int DSManager::GetNumPages()
{
	return numPages;
}


/************************************************************************************
*SetUse function looks sets the bit in the pages array.  This array keeps track of
*the pages that are being used.  If all records in a page are deleted, then that
*page is not really used anymore and can be reused again in the database.  In order
*to know if a page is reusable, the array is checked for any use_bits that are set 
*to zero.  The fixNewPage function firsts checks this array for a use_bit of zero.  
*If one is found, the page is reused.  If not, a new page is allocated.
*************************************************************************************/
void DSManager::SetUse(int index, int use_bit)
{
}

//returns the current use_bit for the corresponding page_id.
int DSManager::GetUse(int index)
{
	return index;
}